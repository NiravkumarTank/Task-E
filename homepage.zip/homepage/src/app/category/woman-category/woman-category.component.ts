import { Component } from '@angular/core';
import { Product } from '../../Interface/interface-all';
import { HttpserviceService } from '../../httpservice.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-woman-category',
  imports: [CommonModule],
  templateUrl: './woman-category.component.html',
  styleUrl: './woman-category.component.css'
})
export class WomanCategoryComponent {
 products: Product[] = []; 
  filteredProducts: Product[] = [];  
  loading: boolean = true;  
  errorMessage: string = ''; 
  showModal: boolean = false; 
  successMessage: string = '';

  selectedSubcategory: string = 'woman';  

  constructor(private http: HttpserviceService) {}

  ngOnInit(): void {
    this.getBySubcategory(this.selectedSubcategory);
  }

  getBySubcategory(subcategory: string): void {
    this.loading = true; 

    this.http.getBySubcategory(subcategory).subscribe(
      (products) => {
        this.products = products;
        this.filteredProducts = products; 
        this.loading = false; 
      },
      (error) => {
        this.errorMessage = 'Error fetching products.';  
        this.loading = false;
      }
    );
  }

 addToCart(product: Product): void {
      if (this.isLoggedIn()) {
        const userId = sessionStorage.getItem('UserId') as string;
        this.http.addToCart(product.productId, userId).subscribe(
          (response) => {
            this.successMessage = "Product added to cart successfully!";
            setTimeout(() => {
              this.successMessage = ''; 
            window.location.reload();

            }, 500); 
          },
          (error) => {
            console.error('Error adding to cart:', error);
          }
        );
      } else {
        this.showModal = true;
      }
    }
  
    isLoggedIn(): boolean {
      const userId = sessionStorage.getItem('UserId');
      return userId !== null;
    }
  
    closeModal(): void {
      this.showModal = false;
    }

  filterBySubcategory(subcategory: string): void {
    this.getBySubcategory(subcategory); 
  }
}
