import { Component } from '@angular/core';

@Component({
  selector: 'app-show-category',
  imports: [],
  templateUrl: './show-category.component.html',
  styleUrl: './show-category.component.css'
})
export class ShowCategoryComponent {

}
