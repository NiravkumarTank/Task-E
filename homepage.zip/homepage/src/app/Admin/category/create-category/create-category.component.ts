import { ChangeDetectorRef, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-category',
  imports: [],
  templateUrl: './create-category.component.html',
  styleUrl: './create-category.component.css'
})
export class CreateCategoryComponent  {



}
