import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, RouterModule } from '@angular/router';

@Component({
  selector: 'app-admin-navbar-page',
  imports: [RouterLink, CommonModule,RouterModule],
  templateUrl: './admin-navbar-page.component.html',
  styleUrl: './admin-navbar-page.component.css'
})
export class AdminNavbarPageComponent {
 isLoggedIn: boolean = false;

  // Method to check sessionStorage for userId
  ngOnInit(): void {
    this.isLoggedIn = !!sessionStorage.getItem('UserId'); 
  }

  logout() {
    sessionStorage.removeItem('UserId'); 
    this.isLoggedIn = false;
  }


constructor(private router: Router) {}
}
