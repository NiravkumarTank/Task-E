import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-navbar-page',
  imports: [RouterLink, CommonModule],
  templateUrl: './navbar-page.component.html',
  styleUrls: ['./navbar-page.component.css']
})
export class NavbarPageComponent implements OnInit {
  isLoggedIn: boolean = false;

  // Method to check sessionStorage for userId
  ngOnInit(): void {
    this.isLoggedIn = !!sessionStorage.getItem('UserId'); 
  }

  logout() {
    sessionStorage.removeItem('UserId'); 
    this.isLoggedIn = false;
  }


constructor(private router: Router) {}



}
