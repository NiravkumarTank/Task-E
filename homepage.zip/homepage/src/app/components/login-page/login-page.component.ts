import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpserviceService } from '../../httpservice.service';
import { passwordStrengthValidator } from '../../Interface/Password-validation';

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, RouterLink],
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent {
  loginForm: FormGroup; // Define FormGroup for the login form
  passwordErrorMessage: string = ''; // To store password validation error messages

  http1 = inject(HttpserviceService);

  constructor(private router: Router, private fb: FormBuilder) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]], // Email must be valid and required
      password: ['', [Validators.required, passwordStrengthValidator()]] // Password must be valid and required
    });
  }

  // Custom password validation

  onSubmit(): void {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      alert('Please fill out the form correctly.');
      return;
    }

    const formData = new FormData();
    formData.append('Email', this.loginForm.value.email);
    formData.append('Password', this.loginForm.value.password);

    // Call the login method from the service
    this.http1.login(formData).subscribe(
      (response: any) => {
        console.log('Login Success');
        alert(response.message);

        sessionStorage.setItem('UserId', response.data.userId);
        sessionStorage.setItem('Role', response.data.firstName);

        const userRole = response.data.role;

 
        this.router.navigate([userRole === 'Admin' ? '/admin' : '/home']).then(() => {
          window.location.reload(); 
        });
      },
      (error) => {
        console.error('Login Error:', error);
        alert('Login failed. Please check your credentials.');
      }
    );
  }

  // Get form controls for easy access in the template
  get email() {
    return this.loginForm.get('email');
  }

  get password() {
    return this.loginForm.get('password');
  }

  // Check if password is invalid for display in UI
  get passwordInvalid() {
    return this.password?.hasError('weakPassword') && this.password?.touched;  // Update here to check for 'weakPassword'
  }

  // Check if email is invalid for display in UI
  get emailInvalid() {
    return this.email?.hasError('email') && this.email?.touched;
  }
}
