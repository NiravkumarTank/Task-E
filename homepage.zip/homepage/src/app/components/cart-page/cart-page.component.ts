
// import { CommonModule } from '@angular/common';
// import { Component, inject } from '@angular/core';
// import { HttpserviceService } from '../../httpservice.service';
// import { HttpClient } from '@angular/common/http';
// import { FormsModule } from '@angular/forms';

// @Component({
//   selector: 'app-cart-page',
//   imports: [CommonModule,FormsModule],
//   templateUrl: './cart-page.component.html',
//   styleUrls: ['./cart-page.component.css']
// })
// export class CartPageComponent {
//   cartItems: any[] = [];
//   totalPrice: number = 0;
//   userId: any = sessionStorage.getItem('UserId');
//   apiMessage: string = ''; // Message to be displayed
//   apiMessageType: string = ''; // Type of message (success or error)

//   constructor(private http: HttpserviceService) { }

//   http1 = inject(HttpClient);

//   ngOnInit() {
//     this.loadCartItems();
//   }

//   loadCartItems() {
//     const userId = sessionStorage.getItem('UserId');
//     if (!userId) {
//       window.location.href = '/login';
//       return;
//     }

//     this.http.getCartItems(userId).subscribe((data: any) => {
//       if (data.message) {
//         this.apiMessage = data.message;
//         this.apiMessageType = 'error';
//       }

//       if (Array.isArray(data)) {
//         this.cartItems = data;
//         if (this.cartItems.length === 0) {
//           this.apiMessage = 'Your cart is empty!';
//           this.apiMessageType = 'error';
//         } else {
//           this.apiMessageType = 'success';
//           // this.apiMessage = 'Cart loaded successfully!';
//           setTimeout(() => {
//             this.apiMessage = ''; // Hide the success message after 3 seconds
//             this.apiMessageType = ''; // Reset the message type
//           }, 3000);
//         }
//       }
//       this.calculateTotalPrice();
//     });
//   }

//   calculateTotalPrice() {
//     this.totalPrice = this.cartItems.reduce((total, item) => total + (item.price * item.stock), 0);
//   }

//   updateQuantity(productId: string) {
//     const data = new FormData();
//     data.append('ProductId', productId);
//     data.append('UserId', this.userId);

//     this.http.updateQuantity(data).subscribe(
//       (response: any) => {
//         this.apiMessage = response.message;
//         this.apiMessageType = 'success';
//         setTimeout(() => {
//           this.apiMessage = '';
//           this.apiMessageType = '';
//           // setTimeout(() => {
//           // window.location.reload()
//           // }, 1000);
//         }, 3000);
//         this.loadCartItems();
//       },
//       (error) => {
//         this.apiMessage = 'An error occurred';
//         this.apiMessageType = 'error';
//       }
//     );
//   }

//   DecreaseQuantity(productId: string) {
//     const data = new FormData();
//     data.append('ProductId', productId);
//     data.append('UserId', this.userId);

//     this.http.DecreaseQuantity(data).subscribe(
//       (response: any) => {
//         this.apiMessage = response.message;
//         this.apiMessageType = 'success';

//         // setTimeout(() => {
//         //   this.apiMessage = ''; 
//         //   this.apiMessageType = '';
//         //   setTimeout(() => {
//         //                   window.location.reload()
//         //             }, 1000);
//         // }, 3000);
//         setTimeout(() => {
//           window.location.reload()
//         }, 1000);
//       },
//       (error) => {
//         this.apiMessage = 'An error occurred';
//         this.apiMessageType = 'error';
//       }
//     );
//   }

//   removeCart(productId: number) {
//     this.http.removeItem(this.userId, productId).subscribe(
//       (response: any) => {
//         this.apiMessage = response.message;
//         this.apiMessageType = 'success';

//         // setTimeout(() => {
//         //   this.apiMessage = ''; 
//         //   this.apiMessageType = '';
//         //    setTimeout(() => {
//         //                   window.location.reload()
//         //             }, 2000);
//         // }, 1000);
//         setTimeout(() => {
//           window.location.reload()
//         }, 1000);
//       },
//       (error) => {
//         this.apiMessage = 'An error occurred';
//         this.apiMessageType = 'error';
//       }
//     );
//   }


//   // onOrderClick(): void {
//   //   const userId = sessionStorage.getItem('UserId');

//   //   if (!userId) {
//   //     alert('User is not logged in.');
//   //     return;
//   //   }

//   //   const address = prompt('Please enter your shipping address:');

//   //   if (!address) {
//   //     alert('Address is required to proceed with the order.');
//   //     return;
//   //   }

//   //   console.log('User ID:', userId);
//   //   console.log('Shipping Address:', address);

//   //   this.http.getCartItems(userId).subscribe(
//   //     (cartData) => {
//   //       if (!cartData || cartData.length === 0) {
//   //         alert('Your cart is empty. Add items to your cart before placing an order.');
//   //         return;
//   //       }

//   //       this.http.placeOrder(userId, address).subscribe(
//   //         (response) => {
//   //           // console.log('Order Response:', response);

//   //           if (response.orderId) {
//   //             alert(response.message)
//   //             // window.location.href = '../Order/order.html';
//   //           } else {
//   //             alert('Failed to place order: ' + response.message);
//   //           }
//   //         },
//   //         (error) => {
//   //           console.error('Error placing the order:', error);
//   //           alert('Error placing the order. See console for details.');
//   //         }
//   //       );
//   //     },
//   //     (error) => {
//   //       console.error('Error fetching cart data:', error);
//   //       alert('Error fetching cart data. See console for details.');
//   //     }
//   //   );
//   // }

//   isAddressOverlayVisible: boolean = false; // Flag to show address input overlay
//   userAddress: string = ''; // Address entered by the user
  
//   onOrderClick(): void {
//     const userId = sessionStorage.getItem('UserId');

//     if (!userId) {
//       alert('User is not logged in.');
//       return;
//     }

//     // Show the overlay for address input
//     this.isAddressOverlayVisible = true;
//   }

//   // Close the overlay
//   closeAddressOverlay() {
//     this.isAddressOverlayVisible = false;
//   }

//   // Submit address and place order
//   placeOrder() {
//     const userId = sessionStorage.getItem('UserId');

//     if (!this.userAddress) {
//       alert('Please enter a valid address to proceed.');
//       return;
//     }

//     this.http.placeOrder(this.userId, this.userAddress).subscribe(
//       (response) => {
//         if (response.orderId) {
//           alert(response.message);
//           this.isAddressOverlayVisible = false; // Close overlay on success
//         } else {
//           alert('Failed to place order: ' + response.message);
//         }
//       },
//       (error) => {
//         console.error('Error placing the order:', error);
//         alert('Error placing the order. See console for details.');
//       }
//     );
//   }
// }
import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { HttpserviceService } from '../../httpservice.service';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-cart-page',
  imports: [CommonModule,FormsModule],
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent {
  cartItems: any[] = [];
  totalPrice: number = 0;
  userId: any = sessionStorage.getItem('UserId');
  apiMessage: string = ''; 
  apiMessageType: string = ''; 
  showAddressPopup: boolean = false; 
  blockNumber: string = ''; 
  houseAddress: string = ''; 
  area: string = ''; 
  areas: string[] = []; 
  state: string = ''; 
  country: string = ''; 
  pinCode: string = '';
  city: string = '';

  constructor(private http: HttpserviceService) { }

  ngOnInit() {
    this.loadCartItems();
  }

  loadCartItems() {
    const userId = sessionStorage.getItem('UserId');
    if (!userId) {
      window.location.href = '/login';
      return;
    }

    this.http.getCartItems(userId).subscribe((data: any) => {
      if (data.message) {
        this.apiMessage = data.message;
        this.apiMessageType = 'error';
      }

      if (Array.isArray(data)) {
        this.cartItems = data;
        if (this.cartItems.length === 0) {
          this.apiMessage = 'Your cart is empty!';
          this.apiMessageType = 'error';
        } else {
          this.apiMessageType = 'success';
          setTimeout(() => {
            this.apiMessage = ''; 
            this.apiMessageType = ''; 
          }, 3000);
        }
      }
      this.calculateTotalPrice();
    });
  }

  calculateTotalPrice() {
    this.totalPrice = this.cartItems.reduce((total, item) => total + (item.price * item.stock), 0);
  }

  openAddressPopup() {
    this.showAddressPopup = true; 
  }

  closeAddressPopup() {
    this.showAddressPopup = false; 
  }

  onSubmit() {
    const fullAddress = `${this.blockNumber}, ${this.houseAddress}, ${this.area},${this.city}, ${this.state}, ${this.country}`;

    this.placeOrder(fullAddress);
    this.closeAddressPopup();
  }

  placeOrder(address: string) {
    const userId = sessionStorage.getItem('UserId');
    if (!userId) {
      alert('User is not logged in.');
      return;
    }

    this.http.getCartItems(userId).subscribe((cartData) => {
      if (!cartData || cartData.length === 0) {
        alert('Your cart is empty. Add items to your cart before placing an order.');
        return;
      }

      this.http.placeOrder(userId, address).subscribe(
        (response) => {
          if (response.orderId) {
            alert('Order placed successfully!');
            window.location.reload();
          } else {
            alert('Failed to place order: ' + response.message);
          }
        },
        (error) => {
          console.error('Error placing the order:', error);
          alert('Error placing the order. See console for details.');
        }
      );
    });
  }


  onPinCodeChange() {
    if (this.pinCode && this.pinCode.length === 6) { 
      this.fetchLocationDetails();
    }
  }

  fetchLocationDetails() {
    this.http.getPincodeInfo(this.pinCode).subscribe(
      (data: any) => {
        console.log(data);
        if (data && data[0] && data[0].PostOffice && data[0].PostOffice.length > 0) {
          const postOffices = data[0].PostOffice;

          // Extract areas (if multiple)
          this.areas = postOffices.map((postOffice: any) => postOffice.Name);
          this.city = postOffices[0].District;
          this.state = postOffices[0].State;
          this.country = postOffices[0].Country;

          // If only one area, auto-select it
          if (this.areas.length === 1) {
            this.area = this.areas[0];
          }
        }
      },
      (error) => {
        console.error('Error fetching location details:', error);
        alert('Failed to fetch location details. Please try again.');
      }
    );
  }
  onOrderClick(): void {
    const userId = sessionStorage.getItem('UserId');
    if (!userId) {
      alert('User is not logged in.');
      return;
    }

    this.openAddressPopup(); // Open the address form popup
  }



  
  updateQuantity(productId: string) {
    const data = new FormData();
    data.append('ProductId', productId);
    data.append('UserId', this.userId);

    this.http.updateQuantity(data).subscribe(
      (response: any) => {
        this.apiMessage = response.message;
        this.apiMessageType = 'success';
        setTimeout(() => {
          this.apiMessage = '';
          this.apiMessageType = '';
          // setTimeout(() => {
          // window.location.reload()
          // }, 1000);
        }, 3000);
        this.loadCartItems();
      },
      (error) => {
        this.apiMessage = 'An error occurred';
        this.apiMessageType = 'error';
      }
    );
  }

  DecreaseQuantity(productId: string) {
    const data = new FormData();
    data.append('ProductId', productId);
    data.append('UserId', this.userId);

    this.http.DecreaseQuantity(data).subscribe(
      (response: any) => {
        this.apiMessage = response.message;
        this.apiMessageType = 'success';

        // setTimeout(() => {
        //   this.apiMessage = ''; 
        //   this.apiMessageType = '';
        //   setTimeout(() => {
        //                   window.location.reload()
        //             }, 1000);
        // }, 3000);
        setTimeout(() => {
          window.location.reload()
        }, 1000);
      },
      (error) => {
        this.apiMessage = 'An error occurred';
        this.apiMessageType = 'error';
      }
    );
  }

  removeCart(productId: number) {
    this.http.removeItem(this.userId, productId).subscribe(
      (response: any) => {
        this.apiMessage = response.message;
        this.apiMessageType = 'success';

        // setTimeout(() => {
        //   this.apiMessage = ''; 
        //   this.apiMessageType = '';
        //    setTimeout(() => {
        //                   window.location.reload()
        //             }, 2000);
        // }, 1000);
        setTimeout(() => {
          window.location.reload()
        }, 1000);
      },
      (error) => {
        this.apiMessage = 'An error occurred';
        this.apiMessageType = 'error';
      }
    );
  }
}
