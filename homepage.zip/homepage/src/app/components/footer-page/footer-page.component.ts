import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-page',
  imports: [],
  templateUrl: './footer-page.component.html',
  styleUrl: './footer-page.component.css'
})
export class FooterPageComponent {

}
