import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpserviceService } from '../../httpservice.service';
import { passwordStrengthValidator } from '../../Interface/Password-validation';

@Component({
  selector: 'app-register-page',
  imports: [CommonModule,ReactiveFormsModule ,RouterLink,HttpClientModule],
  templateUrl: './register-page.component.html',
  styleUrl: './register-page.component.css'
})
export class RegisterPageComponent {
  registrationForm: FormGroup;

  http1 = inject(HttpserviceService);
  constructor(
    private fb: FormBuilder,
    private router: Router
  ) 
  
  {
    this.registrationForm = this.fb.group({
      FirstName: ['', Validators.required],
      LastName: ['', Validators.required],
      Email: ['', [Validators.required, Validators.email]],
      Password: ['', [Validators.required, passwordStrengthValidator()]],
      cPassword: ['', Validators.required],
      PhoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      Gender: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  onSubmit() {
    this.registrationForm.markAllAsTouched();

    if (this.registrationForm.invalid) {
      return;
    }

    const { FirstName, LastName, Email, Password, PhoneNumber, Gender } = this.registrationForm.value;

    if (Password !== this.registrationForm.get('cPassword')?.value) {
      alert('Passwords do not match!');
      return;
    }
    const formData = new FormData();
    formData.append('FirstName', this.registrationForm.value.FirstName);
    formData.append('LastName', this.registrationForm.value.LastName);
    formData.append('Email', this.registrationForm.value.Email);
    formData.append('Password', this.registrationForm.value.Password);
    formData.append('PhoneNumber', this.registrationForm.value.PhoneNumber);
    formData.append('Gender', this.registrationForm.value.Gender);

    this.http1.register( formData).subscribe(
      (response: any) => {
        console.log(response.data);
        
        alert(response.message);
        if (response.message === 'Registration successful') {
          this.router.navigate(['/login']);
        }
      },
      (error) => {
        console.error('Error:', error);
        alert('An error occurred');
      }
    );
  }
}
