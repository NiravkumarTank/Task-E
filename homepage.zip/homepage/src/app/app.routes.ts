import { Routes } from '@angular/router';
import { LoginPageComponent } from './components/login-page/login-page.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { RegisterPageComponent } from './components/register-page/register-page.component';
import { CategoryComponent } from './category/category/category.component';
import { ManCategoryComponent } from './category/man-category/man-category.component';
import { WomanCategoryComponent } from './category/woman-category/woman-category.component';
import { ChildrenCategoryComponent } from './category/children-category/children-category.component';
import { CartPageComponent } from './components/cart-page/cart-page.component';
import { OrderPageComponent } from './components/order-page/order-page.component';
import { HomeImageCarouselComponent } from './components/home-image-carousel/home-image-carousel.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { FooterPageComponent } from './components/footer-page/footer-page.component';
import { ShoesBrandLogosComponent } from './components/shoes-brand-logos/shoes-brand-logos.component';
import { AdminNavbarPageComponent } from './Admin/admin-navbar-page/admin-navbar-page.component';
import { ShowCategoryComponent } from './Admin/category/show-category/show-category.component';
import { CreateCategoryComponent } from './Admin/category/create-category/create-category.component';
import { AdminHomePageComponent } from './Admin/admin-home-page/admin-home-page.component';

export const routes: Routes = [
  // { path: '', component: HomePageComponent },
  {path:'',redirectTo:'home',pathMatch:'full'},
  { path: 'home', component: HomePageComponent },
  { path: 'about-us', component: AboutUsComponent },
  { path: 'login', component: LoginPageComponent },
  { path: 'register', component: RegisterPageComponent },
  { path: 'cart', component: CartPageComponent },
  { path: 'order', component: OrderPageComponent },


  // { path: 'shose-logos', component: ShoesBrandLogosComponent },




  { path: 'admin/', component: AdminHomePageComponent  },
  {
    path: '', component: AdminNavbarPageComponent,
    children: [
      { path: '', redirectTo: 'admin', pathMatch: 'full' },  
      { path: 'admin', component: AdminHomePageComponent, children: [
        // { path: '', component: AdminHomePageComponent }  ,
        { path: 'show-category', component: ShowCategoryComponent }  ,
        { path: 'create-category', component: CreateCategoryComponent }  
      ]},
    ]
  },
  

  { path: 'footer', component: FooterPageComponent },


  {
    path: 'category', component: CategoryComponent,
    children: [
      { path: '', redirectTo: 'man-category', pathMatch: 'full' },
      { path: 'man-category', component: ManCategoryComponent },
      { path: 'woman-category', component: WomanCategoryComponent },
      { path: 'children-category', component: ChildrenCategoryComponent },
    ]
  },

];
