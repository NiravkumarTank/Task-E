﻿namespace NewTask1_j_query.Models.Admin
{
    public class Subcategory
    {
        public int sc_id {  get; set; }
        public string sc_Name { get; set; }
        public int c_id { get; set; }
    }
}
