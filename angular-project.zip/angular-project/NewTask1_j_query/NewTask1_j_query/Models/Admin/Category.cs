﻿using System.ComponentModel.DataAnnotations;

namespace NewTask1_j_query.Models.Admin
{
    public class Category
    {
        public int c_Id { get; set; }

        public string? c_Name { get; set; }
    }
}
