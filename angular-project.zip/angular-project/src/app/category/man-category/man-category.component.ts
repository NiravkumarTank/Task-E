import { Component } from '@angular/core';
import { Product } from '../../Interface/interface-all';
import { HttpserviceService } from '../../httpservice.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-man-category',
  imports: [CommonModule],
  templateUrl: './man-category.component.html',
  styleUrl: './man-category.component.css'
})
export class ManCategoryComponent {

   products: Product[] = []; 
    filteredProducts: Product[] = [];  
    loading: boolean = true;  
    errorMessage: string = ''; 
  
    selectedSubcategory: string = 'Man';  
  
    constructor(private http: HttpserviceService) {}
  
    ngOnInit(): void {
      this.getBySubcategory(this.selectedSubcategory);
    }
  
    getBySubcategory(subcategory: string): void {
      this.loading = true; 
  
      this.http.getBySubcategory(subcategory).subscribe(
        (products) => {
          this.products = products;
          this.filteredProducts = products; 
          this.loading = false; 
        },
        (error) => {
          this.errorMessage = 'Error fetching products.';  
          this.loading = false;
        }
      );
    }
  
    addToCart(product: Product): void {
      console.log('Product added to cart:', product); 
    }
  
    filterBySubcategory(subcategory: string): void {
      this.getBySubcategory(subcategory); 
    }
}
