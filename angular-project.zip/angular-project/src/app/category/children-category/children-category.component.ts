import { Component, OnInit } from '@angular/core';
import { Product } from '../../Interface/interface-all';  // Assuming you have an interface for the product
import { HttpserviceService } from '../../httpservice.service';  // Your HTTP service
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-children-category',
  imports: [CommonModule],
  templateUrl: './children-category.component.html',
  styleUrls: ['./children-category.component.css']
})
export class ChildrenCategoryComponent implements OnInit {
  products: Product[] = []; 
  filteredProducts: Product[] = [];  
  loading: boolean = true;  
  errorMessage: string = ''; 

  selectedSubcategory: string = 'children';  

  constructor(private http: HttpserviceService) {}

  ngOnInit(): void {
    this.getBySubcategory(this.selectedSubcategory);
  }

  getBySubcategory(subcategory: string): void {
    this.loading = true; 

    this.http.getBySubcategory(subcategory).subscribe(
      (products) => {
        this.products = products;
        this.filteredProducts = products; 
        this.loading = false; 
      },
      (error) => {
        this.errorMessage = 'Error fetching products.';  
        this.loading = false;
      }
    );
  }

  addToCart(product: Product): void {
    console.log('Product added to cart:', product); 
  }

  filterBySubcategory(subcategory: string): void {
    this.getBySubcategory(subcategory); 
  }
}
