import { Component } from '@angular/core';
import { Product } from '../../Interface/interface-all';
import { HttpserviceService } from '../../httpservice.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-woman-category',
  imports: [CommonModule],
  templateUrl: './woman-category.component.html',
  styleUrl: './woman-category.component.css'
})
export class WomanCategoryComponent {
 products: Product[] = []; 
  filteredProducts: Product[] = [];  
  loading: boolean = true;  
  errorMessage: string = ''; 

  selectedSubcategory: string = 'woman';  

  constructor(private http: HttpserviceService) {}

  ngOnInit(): void {
    this.getBySubcategory(this.selectedSubcategory);
  }

  getBySubcategory(subcategory: string): void {
    this.loading = true; 

    this.http.getBySubcategory(subcategory).subscribe(
      (products) => {
        this.products = products;
        this.filteredProducts = products; 
        this.loading = false; 
      },
      (error) => {
        this.errorMessage = 'Error fetching products.';  
        this.loading = false;
      }
    );
  }

  addToCart(product: Product): void {
    console.log('Product added to cart:', product); 
  }

  filterBySubcategory(subcategory: string): void {
    this.getBySubcategory(subcategory); 
  }
}
