export interface Product {
    category: string;
    description: string;
    imageUrl: string;
    name: string;
    price: number;
    productId: number;
    stock: number;
    subcategory: string;
  }
  