import { Routes } from '@angular/router';
import { LoginPageComponent } from './components/login-page/login-page.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { RegisterPageComponent } from './components/register-page/register-page.component';
import { CategoryComponent } from './category/category/category.component';
import { ManCategoryComponent } from './category/man-category/man-category.component';
import { WomanCategoryComponent } from './category/woman-category/woman-category.component';
import { ChildrenCategoryComponent } from './category/children-category/children-category.component';
import { CartPageComponent } from './components/cart-page/cart-page.component';
import { OrderPageComponent } from './components/order-page/order-page.component';

export const routes: Routes = [
    { path: '', component: HomePageComponent },  
    { path: 'home', component: HomePageComponent },  
    // { path: 'category', component: CategoryComponent },  
    { path: 'login', component: LoginPageComponent },
    { path: 'register', component: RegisterPageComponent },
    { path: 'cart', component: CartPageComponent },
    { path: 'order', component: OrderPageComponent },
    { path: 'category', component: CategoryComponent, 
        children: [
          { path: '', redirectTo: 'man-category', pathMatch: 'full' }, 
        //   { path: 'category', component: CategoryComponent },
          { path: 'man-category', component: ManCategoryComponent },
          { path: 'woman-category', component: WomanCategoryComponent },
          { path: 'children-category', component: ChildrenCategoryComponent },
        ] 
      },
      
];
