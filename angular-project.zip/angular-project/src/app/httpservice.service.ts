import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from './Interface/interface-all';

@Injectable({
  providedIn: 'root'
})
export class HttpserviceService {

  constructor(private http: HttpClient) { }
  private apiUrl = 'https://localhost:7262/api'; 
 



  login(data:any){
    return  this.http.post(this.apiUrl+"/User/Login",data);
  }

  register(data:any){
    return this.http.post(this.apiUrl+"/User/Registration",data);
  }
  
  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl+"/Admin/ShowAllProduct");
  }


  getBySubcategory(subcategory: string): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.apiUrl}/Admin/SubCategoryName/${subcategory}`);
  }


  addToCart(productId: number, userId: string): Observable<any> {
    const formData = new FormData();
    formData.append('ProductId', productId.toString());
    formData.append('UserId', userId);

    return this.http.post(this.apiUrl+"/Cart/AddToCart", formData);
  }



  userId:any = sessionStorage.getItem('UserId');

  getCartItems(userId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl+"/Cart"}/${userId}`);
  }




  updateQuantity(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/Cart/AddToCart`, data);
  }
  
  DecreaseQuantity(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/Cart/DecreaseStock`, data);
  }

  removeItem(userId: string, productId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/Cart/DeleteCart?uid=${userId}&pid=${productId}`);
  }
}
