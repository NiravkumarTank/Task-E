import { Component } from '@angular/core';

@Component({
  selector: 'app-order-page',
  imports: [],
  templateUrl: './order-page.component.html',
  styleUrl: './order-page.component.css'
})
export class OrderPageComponent {

}
