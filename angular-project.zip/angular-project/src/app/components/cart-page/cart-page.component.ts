import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { HttpserviceService } from '../../httpservice.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-cart-page',
  imports: [CommonModule],
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent {
  cartItems: any[] = [];
  totalPrice: number = 0;
  userId: any = sessionStorage.getItem('UserId');
  apiMessage: string = ''; // Message to be displayed
  apiMessageType: string = ''; // Type of message (success or error)

  constructor(private http: HttpserviceService) { }

  http1 = inject(HttpClient);

  ngOnInit() {
    this.loadCartItems();
  }

  loadCartItems() {
    const userId = sessionStorage.getItem('UserId');
    if (!userId) {
      window.location.href = '/login';
      return;
    }

    this.http.getCartItems(userId).subscribe((data: any) => {
      if (data.message) {
        this.apiMessage = data.message;
        this.apiMessageType = 'error';
      }

      if (Array.isArray(data)) {
        this.cartItems = data;
        if (this.cartItems.length === 0) {
          this.apiMessage = 'Your cart is empty!';
          this.apiMessageType = 'error';
       
        } else {
          this.apiMessageType = 'success';
        }
      }
      this.calculateTotalPrice();

      setTimeout(() => {
        this.apiMessage = '';
        this.apiMessageType = '';
      }, 2000);
    });
  }

  calculateTotalPrice() {
    this.totalPrice = this.cartItems.reduce((total, item) => total + (item.price * item.stock), 0);
  }

  updateQuantity(productId: string) {
    const data = new FormData();
    data.append('ProductId', productId);
    data.append('UserId', this.userId);

    this.http.updateQuantity(data).subscribe(
      (response: any) => {
        this.apiMessage = response.message;
        this.apiMessageType = 'success';
        this.loadCartItems();
      },
      (error) => {
        this.apiMessage = 'An error occurred';
        this.apiMessageType = 'error';
      }
    );
  }

  DecreaseQuantity(productId: string) {
    const data = new FormData();
    data.append('ProductId', productId);
    data.append('UserId', this.userId);

    this.http.DecreaseQuantity(data).subscribe(
      (response: any) => {
        this.apiMessage = response.message;
        this.apiMessageType = 'success';

      //   setTimeout(() => {
      //     this.loadCartItems();
      //   }, 3000);
      // },
      setTimeout(() => {
          setTimeout(() => {
            window.location.reload()
          }, 1);
      }, 1000);
    },
      (error) => {
        this.apiMessage = 'An error occurred';
        this.apiMessageType = 'error';
      }
    );
  }

  removeCart(productId: number) {
    this.http.removeItem(this.userId, productId).subscribe(
      (response: any) => {
        this.apiMessage = response.message;
        this.apiMessageType = 'success';

        setTimeout(() => {
          // this.loadCartItems();
            setTimeout(() => {
              window.location.reload()
            }, 1);
        }, 1000);
      },
      (error) => {
        this.apiMessage = 'An error occurred';
        this.apiMessageType = 'error';
      }
    );
  }
}
