import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpserviceService } from '../../httpservice.service';
import { Product } from '../../Interface/interface-all';

@Component({
  selector: 'app-home-page',
  imports: [CommonModule, RouterModule],
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  products: Product[] = [];
  loading: boolean = true;
  errorMessage: string = '';
  showModal: boolean = false; // To manage modal visibility

  constructor(private http: HttpserviceService) { }

  ngOnInit(): void {
    this.http.getProducts().subscribe(
      (data) => {
        this.products = data;
        this.loading = false;
      },
      (error) => {
        this.errorMessage = 'Failed to load products.';
        this.loading = false;
      }
    );
  }



  addToCart(product: Product): void {
    if (this.isLoggedIn()) {
      const userId = sessionStorage.getItem('UserId') as string;
      this.http.addToCart(product.productId, userId).subscribe(
        (response) => {
          // console.log('Product added to cart successfully:', response);
          alert("Product added to cart successfully");
          window.location.reload();
        },
        (error) => {
          console.error('Error adding to cart:', error);
        }
      );
    } else {
      this.showModal = true;
    }
  }

  isLoggedIn(): boolean {
    const userId = sessionStorage.getItem('UserId');
    return userId !== null;
  }

  closeModal(): void {
    this.showModal = false; // Close the modal when the user clicks the "Close" button
  }
}
