﻿using System.Text;

namespace EmailSender.Common
{
    public static class CommonMethods
    {
        public static string key = "@#$%^&*()!+=EHskDB";

        public static string ConvertToEncrypt(string password)
        {
            if (password == null)
            {
                return "";
            }
            password += key;
            var passwordBytes = Encoding.UTF8.GetBytes(password);
            return Convert.ToBase64String(passwordBytes);
        }

        public static string ConvertToDecrypt(string base64EncodeDate)
        {
            if (base64EncodeDate == null)
            {
                return string.Empty;
            }
            var base64Bytes = Convert.FromBase64String(base64EncodeDate);
            var result = Encoding.UTF8.GetString(base64Bytes);
            result = result.Substring(0, result.Length - key.Length);
            return result;
        }

    }
}
