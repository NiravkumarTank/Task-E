﻿namespace EmailSender.Models
{
    public class UserData
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string password { get; set; }
    }
}
