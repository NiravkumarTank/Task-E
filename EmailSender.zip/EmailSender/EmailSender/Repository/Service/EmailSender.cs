﻿using System.Net;
using System.Net.Mail;
using EmailSender.Models;
using EmailSender.Repository.Interface;

namespace EmailSender.Repository.Service
{
    public class EmailSenders : IEmailSender
    {
        private readonly IConfiguration _configuration;
        public EmailSenders(IConfiguration configuration)
        {
            this._configuration = configuration;
        }

        public async Task<bool> EmailSenderAsync(string email, string subject, string message)
        {
           
            bool status = false;
            try
            {
                GetEmailSetting getEmailSetting = new GetEmailSetting()
                {
                    SecretKey = _configuration.GetValue<string>("AppSettings:SecretKey"),
                    From = _configuration.GetValue<string>("AppSettings:EmailSettings:From"),
                    SmtpServer = _configuration.GetValue<string>("AppSettings:EmailSettings:SmtpServer"),
                    Port = _configuration.GetValue<int>("AppSettings:EmailSettings:Port"),
                    EnableSSL = _configuration.GetValue<bool>("AppSettings:EmailSettings:EnableSSL"),
                };

                MailMessage mailMessage = new MailMessage()
                {
                    From = new MailAddress(getEmailSetting.From),
                    Subject = subject,
                    Body = message
                };

                mailMessage.To.Add(email);
                SmtpClient smtpClient = new SmtpClient(getEmailSetting.SmtpServer)
                {
                    Port = getEmailSetting.Port,
                    Credentials = new NetworkCredential(getEmailSetting.From, getEmailSetting.SecretKey),
                    EnableSsl = getEmailSetting.EnableSSL
                };

                await smtpClient.SendMailAsync(mailMessage);
                status = true;

            }
            catch (Exception ex)
            {
                status = false;
                // Log exception or return a more detailed error message
                Console.WriteLine($"Error occurred: {ex.Message}");
            }

            return status;
        }
    }
}
