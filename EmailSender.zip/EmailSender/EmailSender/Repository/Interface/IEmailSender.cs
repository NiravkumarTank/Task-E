﻿namespace EmailSender.Repository.Interface
{
    public interface IEmailSender
    {
        Task<bool> EmailSenderAsync(string email, string subject, string message);
    }
}
