﻿using EmailSender.Repository.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmailSender.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private readonly IEmailSender emailSender;

        public EmailController(IEmailSender emailSender)
        {
            this.emailSender = emailSender;
        }
        [HttpPost]
        public async Task<IActionResult> Email(string emailAddress)
        {
            await emailSender.EmailSenderAsync(emailAddress,"first email","email send ");
            return Ok(emailAddress);
        }
    }
}
