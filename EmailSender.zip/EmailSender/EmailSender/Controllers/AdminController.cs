﻿using System.Data;
using System.Net.Mail;
using System.Security.Cryptography;
using EmailSender.Common;
using EmailSender.Models;
using EmailSender.Repository.Interface;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace EmailSender.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly string ConnetionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ADO;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";

        private readonly IEmailSender emailSender;

        public AdminController(IEmailSender emailSender)
        {
            this.emailSender = emailSender;
        }

        [HttpPost]
        [Route("Registration")]
        public ActionResult<UserData> CreatUser([FromForm] UserData user)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);

            string emailCheck = "SELECT COUNT(1) FROM Userdemo WHERE Name = @name";
            SqlCommand checkEmailCmd = new SqlCommand(emailCheck, conn);
            checkEmailCmd.Parameters.AddWithValue("@name", user.Name);

            conn.Open();
            int emailExists = (int)checkEmailCmd.ExecuteScalar();
            conn.Close();

            if (emailExists > 0)
            {
                return Ok(new { message = "Email already exists" });
            }
            var salt = new byte[128/8];
            using (var rendon = RandomNumberGenerator.Create())
            {
                rendon.GetBytes(salt);
            }

            var hash = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                    password: user.password,
                    salt: salt,
                    prf : KeyDerivationPrf.HMACSHA256,
                    iterationCount:10000,
                    numBytesRequested:256/8
                ));

            SqlCommand cmd = new SqlCommand("insert into Userdemo (name,password,solt) values(@name,@password,@solt)", conn);
            //cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", user.Name);
            cmd.Parameters.AddWithValue("@password",hash);
            cmd.Parameters.AddWithValue("@solt", Convert.ToBase64String(salt));


            conn.Open();
            int row = cmd.ExecuteNonQuery();
            conn.Close();

            if (row > 0)
            {
                return Ok(new { data = user.Name, message = "Registration successful" });
            }
            else
            {
                return BadRequest(new { message = "Error, no data inserted" });
            }

        }



        [HttpPost]
        [Route("Login")]
        public ActionResult<Login> LoginData([FromForm] Login login)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);

            SqlCommand cmd = new SqlCommand("SELECT password,solt FROM Userdemo WHERE name = @name ", conn);
            //cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", login.Name);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
               var datapassword = reader["Password"].ToString();
                byte[] saltdata = Convert.FromBase64String(reader["solt"].ToString());

                var hash = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                    password: login.Password,
                    salt: saltdata,
                    prf: KeyDerivationPrf.HMACSHA256,
                    iterationCount: 10000,
                    numBytesRequested: 256 / 8
                ));


                conn.Close();
                if (datapassword == hash)
                {
                    conn.Close();
                    return Ok(new { message = "login successfully" });
                }


                conn.Close();
                return Ok(new { message = "Invalid Email or password" });
            }
            else
            {
                conn.Close();
                return Ok(new { message = "Invalid Email or password" });
            }
        }





        [HttpPost]
        [Route("ForgotPassword")]
        public ActionResult ForgotPassword(string name)
        {
            using (SqlConnection conn = new SqlConnection(ConnetionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Userdemo WHERE name = @name", conn);
                cmd.Parameters.AddWithValue("@name", name);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    Random random = new Random();
                    int otp = random.Next(100000, 1000000);

                    // Store the OTP and its expiration time (e.g., 5 minutes)
                    StoreOtpForUser(name, otp);

                    // You can uncomment this to send email in the production environment
                     emailSender.EmailSenderAsync(name, "OTP for Password Reset", "Your OTP for password reset is: " + otp);

                    return Ok(new { message = "OTP sent successfully", otp = otp });
                }
                else
                {
                    return Ok(new { message = "Invalid Username" });
                }
            }
        }

        // Temporary in-memory storage for OTP (use cache or database in production)
        private static Dictionary<string, (int otp, DateTime expirationTime)> otpStorage = new Dictionary<string, (int otp, DateTime expirationTime)>();

        // Store OTP with expiration time
        private void StoreOtpForUser(string name, int otp)
        {
            var expirationTime = DateTime.Now.AddMinutes(5); // OTP expires in 5 minutes
            otpStorage[name] = (otp, expirationTime);
        }

        // Get the OTP for the user (returns 0 if expired or not found)
        private (int otp, DateTime expirationTime) GetOtpForUser(string name)
        {
            if (otpStorage.ContainsKey(name))
            {
                var otpData = otpStorage[name];
                if (otpData.expirationTime > DateTime.Now)
                {
                    return otpData;
                }
            }
            return (0, DateTime.MinValue);
        }


        [HttpPost]
        [Route("VerifyOtpAndChangePassword")]
        public ActionResult VerifyOtpAndChangePassword(int userId, int enteredOtp, string newPassword)
        {
            // Connect to the database and fetch the user's name using userId
            SqlConnection conn1 = new SqlConnection(ConnetionString);
            SqlCommand comd1 = new SqlCommand("SELECT name FROM Userdemo WHERE id = @id", conn1);
            comd1.Parameters.AddWithValue("@id", userId); // Use userId parameter for the query
            conn1.Open();

            var dataname = comd1.ExecuteScalar() as string; // Cast to string

            if (string.IsNullOrEmpty(dataname))
            {
                return BadRequest(new { message = "User not found" });
            }

            // Now you can use dataname as the username to verify OTP
            var otpData = GetOtpForUser(dataname);

            if (otpData.otp != enteredOtp || otpData.expirationTime < DateTime.Now)
            {
                return BadRequest(new { message = "Invalid or expired OTP" });
            }

            // Generate a salt for password hashing
            var salt = new byte[128 / 8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            // Hash the new password using PBKDF2
            var hash = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: newPassword,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 256 / 8
            ));

            // Update the user's password in the database using their name
            using (SqlConnection conn = new SqlConnection(ConnetionString))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Userdemo SET password = @newPassword, solt = @salt WHERE name = @name", conn);
                cmd.Parameters.AddWithValue("@newPassword", hash);
                cmd.Parameters.AddWithValue("@name", dataname); // Use the fetched name here
                cmd.Parameters.AddWithValue("@salt", Convert.ToBase64String(salt));

                conn.Open();
                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    return Ok(new { message = "Password updated successfully" });
                }
                else
                {
                    return BadRequest(new { message = "Failed to update password" });
                }
            }
        }


    }
}
