create table Category(
				c_id int identity(1,1) primary key,
				c_Name varchar(20) not null);
select * from Category
go


create table Product (ProductId int Identity(1,1) primary key,
					Name varchar(100) not null,
					Description varchar(150) not null,
					c_id int not null,
					Price decimal(18,2) not null,
					Stock int not null,
					ImageUrl varchar(255),
					CreatedDate Date default(getdate()),
					Foreign key(c_id) references Category(c_id) on delete cascade
			)
go



--create user table 
Create Table UserModel (UserId int identity(1,1)primary key,
				FirstName varchar(100) not null,
				LastName varchar(100) not null,
				Email varchar(100) not null,
				Password varchar(100) not null,
				PhoneNumber varchar(100) not null,
				Gender varchar(100) 
			)
go


create Table Cart(CartId int identity(1,1) primary key ,  
				UserId int  ,
				ProductId int ,
				Stock int   ,
				Foreign key(Userid) references UserModel(UserId) on delete cascade,
				Foreign key(ProductId) references Product(ProductId) on delete cascade
				)
go

create table OrderTable (OrderId identity(1,1) primary key,
				UserId int,
				OrderDate Date default(GetDate()),
				Status varchar(10) default('false'),
				Foreign key(Userid) references UserModel(UserId) on delete cascade)

CREATE TABLE OrderItems (
    OrderItemId INT IDENTITY(1,1) PRIMARY KEY,
    OrderId INT,
    ProductId INT,
    Quantity INT,
    UserId INT,
    FOREIGN KEY (OrderId) REFERENCES OrderTable(OrderId),
    FOREIGN KEY (ProductId) REFERENCES Product(ProductId),
    FOREIGN KEY (UserId) REFERENCES UserModel(UserId)
);

select * from UserModel
select * from Product
select * from Cart
select * from OrderTable
select * from OrderItems

--insert product using procedure 
alter procedure Insert_product(
	@name varchar(100),
	@description varchar(150),
	@catagory int,
	@price decimal(18,2),
	@stock int,
	@imageurl varchar(255)
)
as
	begin
		insert into Product (Name,Description,c_id,Price,Stock,ImageUrl) 
                 values (@name,@description,@catagory,@price,@stock,@imageurl);
end
go
select * from Product
go
--select All Product
ALTER PROCEDURE Select_All
AS
BEGIN
    SELECT p.ProductId, p.Name, p.Description, c.c_Name, p.Price, p.Stock, p.ImageUrl 
    FROM Product p 
    JOIN Category c ON p.c_id = c.c_id
END
GO


--select By Id Product
ALTER PROCEDURE SelectById(@id INT)
AS
BEGIN
    SELECT 
        p.ProductId,p.Name,p.Description,c.c_Name AS Category,p.Price,p.Stock,p.ImageUrl 
    FROM 
        Product p JOIN Category c ON p.c_id = c.c_id
    WHERE 
        p.ProductId = @id; 
END
GO




alter table UserModel add 
				Role varchar(20) default('User') with values;
--insert into UserModel values('admin','admin','admin@gmail.com','admin','1234567890','Male','Admin')
select * from UserModel 



go
-- insert data in userModel table 
alter procedure  Insert_UserModel(
		@fname varchar(100),
		@lname varchar(100),
		@email varchar(100),
		@password varchar(100),
		@phonenumber varchar(100),
		@gender varchar(100)
	)
As
	Begin
		insert into UserModel (FirstName,LastName,Email,Password,PhoneNumber,Gender)
                            Values (@fname,@lname,@email,@password,@phonenumber,@gender)
	End
go

--Select All User
alter procedure SelectAllUserModel
As
	Begin
		select * from UserModel where Role = 'User';
	End
go

--Select By Id User
Create Procedure SelectByIdUserModel(@UserId int)
As
	Begin
		Select * from UserModel Where UserId = @UserId;
	end
go
select * from Cart

--Update User By Id
alter Procedure UpdateUserModel(
		@id int,
		@fname varchar(100),
		@lname varchar(100),
		@email varchar(100),
		@phone varchar(100),
		@gender varchar(100)
	)
As
	Begin
		Update UserModel set FirstName = @fname ,LastName = @lname ,
				Email=@email,PhoneNumber=@phone,
                         Gender = @gender Where UserId = @id;
	End
go

--Delete User
Create Procedure DeleteUserModel(@id int)
as
	begin
		Delete From UserModel Where UserId = @id;
	end
go

--login 
alter PROCEDURE CheckUserLogin
    @email varchar(100),
    @pws varchar(100)
AS
BEGIN
    SELECT UserId,FirstName,Email, Password,Role
    FROM UserModel
    WHERE Email = @email AND Password = @pws;
END;
GO




create procedure updtaeCartProductStock
(@UserId int ,@ProductId int)
as
begin
	Update Cart set Stock = Stock + 1 where UserId = @UserId;
	UPDATE Product SET Stock = Stock - 1 WHERE ProductId = @ProductId;
end;



alter PROCEDURE updtaeCartProductStock
    @UserId INT,
    @ProductId INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Product WHERE ProductId = @ProductId AND Stock = 0)
    BEGIN        
        RETURN 0; 
    END

    UPDATE Cart
    SET Stock = Stock + 1
    WHERE ProductId = @ProductId;

    UPDATE Product
    SET Stock = Stock - 1
    WHERE ProductId = @ProductId;
END;

exec updtaeCartProductStock @UserId  = 1002 , @ProductId = 1004



alter PROCEDURE insertCartProductStock
    @uid INT,
    @pid INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Product WHERE ProductId = @pid AND Stock = 0)
    BEGIN       
        RETURN 0; 
    END

    INSERT INTO Cart (UserId, ProductId,Stock) VALUES (@uid, @pid,'1')

    UPDATE Product
    SET Stock = Stock - 1
    WHERE ProductId = @pid;
END;

exec insertCartProductStock @uid  = 1002 , @pid = 1004

UPDATE Product  SET Stock = 2 WHERE ProductId = 1004

select * from UserModel
select * from Product
select * from Cart
go
--Show All Cart 
alter procedure ShowAllCart(@UserId int)
as
	begin
		 select p.ProductId, p.ImageUrl,p.Name,p.Price,c.Stock,c.CartId from Cart c 
			join UserModel u  on u.UserId = c.UserId
			join Product p on c.ProductId = p.ProductId where u.UserId  = @UserId
	End
go


alter procedure decreaseStock(
	@uid INT,
    @pid INT)
AS
BEGIN 
    Update  Cart set Stock = Stock - 1 Where UserId = @uid and ProductId = @pid;

	IF EXISTS (SELECT 1 FROM Cart WHERE UserId = @uid AND ProductId = @pid AND Stock = 0)
			BEGIN
				DELETE FROM Cart WHERE UserId = @uid AND ProductId = @pid;
			END
    UPDATE Product SET Stock = Stock + 1 WHERE ProductId = @pid;
	
END
go

--exec decreaseStock @uid = 1, @pid = 1004


go
create procedure removeToCart(@id int ,@uid int )
as
	begin
		 DECLARE @removeStock INT;
	
		 SELECT @removeStock = Stock FROM Cart WHERE ProductId = @id and UserId = @uid;

		Delete from Cart where ProductId = @id and UserId = @uid;

		UPDATE Product SET Stock = Stock+@removeStock  WHERE ProductId = @id;
	end
go



