﻿using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using NewTask1_j_query.Models.Admin;

namespace NewTask1_j_query.Controllers.Admin
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly string ConnetionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Task_E-Commerce;Integrated Security=True;Trust Server Certificate=True";

        [HttpPost]
        [Route("AddProduct")]
        public ActionResult<Product> DataAdd([FromForm]Product product)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);


            if (product.Image != null)
            {
                var path = Path.Combine(Directory.GetCurrentDirectory(), "Upload");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                var filePath = Path.Combine(path, $"{Guid.NewGuid()}_{Path.GetFileName(product.Image.FileName)}");
                using (var fs = new FileStream(filePath, FileMode.Create))
                {
                     product.Image.CopyTo(fs);
                }
                product.ImageUrl = Path.GetFileName(filePath);
            }

            SqlCommand cmd = new SqlCommand("Insert_product", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name",product.Name);
            cmd.Parameters.AddWithValue("@description", product.Description);
            cmd.Parameters.AddWithValue("@catagory", product.Category);
            cmd.Parameters.AddWithValue("@price", product.Price);
            cmd.Parameters.AddWithValue("@stock", product.Stock);
            cmd.Parameters.AddWithValue("@imageurl", product.ImageUrl);

            conn.Open();
            int row =  cmd.ExecuteNonQuery();
            conn.Close();
            if (row > 0)
            {
                return Ok(product);
            } 
            else 
            {
                return BadRequest();
            }
        }



        [HttpGet]
        [Route("ShowAllProduct")]
        public ActionResult<List<Product>> GetAll()
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            List<Product> AllProdcuct = new List<Product>();

            SqlCommand cmd = new SqlCommand("Select_All", conn);
            cmd.CommandType= CommandType.StoredProcedure;
            conn.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Product product = new Product
                {
                    ProductId = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Description = reader.GetString(2),
                    Category = reader.GetString(3),
                    Price = reader.GetDecimal(4),
                    Stock = reader.GetInt32(5),
                    ImageUrl = reader.GetString(6),
                    CreatedDate =DateOnly.FromDateTime (reader.GetDateTime(7))
                };
                AllProdcuct.Add(product);
            }

            var data = AllProdcuct.Select(item => new
            {
                item.ProductId,
                item.Name,
                item.Description,
                item.Category,
                item.Price,
                item.Stock,
                ImageUrl = $"{Request.Scheme}:/{Request.Host}/Upload/{item.ImageUrl}",
                item.CreatedDate
            });
            conn.Close();
            return Ok(data);
        }



        [HttpGet]
        [Route("GetById/{id}")]
        public ActionResult<Product> GetById(int id)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);

            SqlCommand cmd = new SqlCommand("SelectById", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                Product product = new Product
                {
                    ProductId = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Description = reader.GetString(2),
                    Category = reader.GetString(3),
                    Price = reader.GetDecimal(4),
                    Stock = reader.GetInt32(5),
                    ImageUrl = reader.GetString(6),
                    CreatedDate = DateOnly.FromDateTime(reader.GetDateTime(7))
                };

                var data = new
                {
                    product.ProductId,
                    product.Name,
                    product.Description,
                    product.Category,
                    product.Price,
                    product.Stock,
                    ImageUrl = $"{Request.Scheme}:/{Request.Host}/Upload/{product.ImageUrl}",
                    product.CreatedDate
                };
                conn.Close();
                return Ok(data);
            }
            else
            {
                return NotFound(new { message = id +" not found" });
            }
            
        }


        [HttpDelete]
        [Route("DeleteById/{id}")]
        public ActionResult DeleteById(int id)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            string query = "Select ImageUrl from Product where ProductId = @id";

            SqlCommand cmd1 = new SqlCommand(query, conn);
            cmd1.Parameters.AddWithValue("@id", id);
            conn.Open();
            string image = Convert.ToString(cmd1.ExecuteScalar());
            
            var imagePath = Path.Combine(Directory.GetCurrentDirectory(), "Upload", image);

            if (System.IO.File.Exists(imagePath))
            {
                System.IO.File.Delete(imagePath);
            }
            string query1 = "delete from Product Where ProductId = @id";
            SqlCommand command1 = new SqlCommand(query1, conn);

            command1.Parameters.AddWithValue("@id", id);

            command1.ExecuteNonQuery();
            conn.Close();
            return Ok(new { message = id + "   Delete data" });
        }




    }
}
