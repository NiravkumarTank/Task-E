﻿using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using NewTask1_j_query.Models.Admin;
using NewTask1_j_query.Models.Dtos;

namespace NewTask1_j_query.Controllers.Admin
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly string ConnetionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Task_E_Commerce;Integrated Security=True;Trust Server Certificate=True";

        [HttpPost]
        [Route("AddProduct")]
        public ActionResult<ProductAddDto> DataAdd([FromForm] ProductAddDto productDto)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);

            //SqlCommand checkCategoryCmd = new SqlCommand("SELECT COUNT(*) FROM Category WHERE c_Id = @CategoryId", conn);
            //checkCategoryCmd.Parameters.AddWithValue("@CategoryId", productDto.c_id);  
            //conn.Open();
            //int categoryCount = (int)checkCategoryCmd.ExecuteScalar();
            //conn.Close();

            //if (categoryCount == 0)
            //{
            //    return BadRequest("The selected Category ID does not exist.");
            //}

            if (productDto.Image != null)
            {
                var path = Path.Combine(Directory.GetCurrentDirectory(), "Upload");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                var filePath = Path.Combine(path, $"{Guid.NewGuid()}_{Path.GetFileName(productDto.Image.FileName)}");
                using (var fs = new FileStream(filePath, FileMode.Create))
                {
                    productDto.Image.CopyTo(fs);
                }
                productDto.ImageUrl = Path.GetFileName(filePath);
            }

            // Insert the product using the stored procedure
            SqlCommand cmd = new SqlCommand("Insert_product", conn)
            {
                CommandType = CommandType.StoredProcedure
            };
            cmd.Parameters.AddWithValue("@name", productDto.Name);
            cmd.Parameters.AddWithValue("@description", productDto.Description);
            cmd.Parameters.AddWithValue("@catagory", productDto.c_id); // Passing the category ID (c_id)
            cmd.Parameters.AddWithValue("@price", productDto.Price);
            cmd.Parameters.AddWithValue("@stock", productDto.Stock);
            cmd.Parameters.AddWithValue("@imageurl", productDto.ImageUrl);

            conn.Open();
            int row = cmd.ExecuteNonQuery();
            conn.Close();

            if (row > 0)
            {
                return Ok(new { message ="inserted data ",data= productDto });
            }
            else
            {
                return BadRequest("Failed to insert product into the database.");
            }
        }




        [HttpGet]
        [Route("ShowAllProduct")]
        public ActionResult<List<ShowProductDto>> GetAllProducts()
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            List<ShowProductDto> products = new List<ShowProductDto>();

            SqlCommand cmd = new SqlCommand("Select_All", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ShowProductDto product = new ShowProductDto
                {
                    ProductId = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Description = reader.GetString(2),
                    Category = reader.GetString(3), // Category name
                    Price = reader.GetDecimal(4),
                    Stock = reader.GetInt32(5),
                    ImageUrl = reader.GetString(6)
                };

                products.Add(product);
            }
            var data = products.Select(item => new
            {
                item.ProductId,
                item.Name,
                item.Description,
                item.Category,
                item.Price,
                item.Stock,
                ImageUrl = $"{Request.Scheme}:/{Request.Host}/Upload/{item.ImageUrl}"
                
            });

           conn.Close();

            return Ok(data); 
        }



       [HttpGet]
        [Route("GetById/{id}")]
        public ActionResult<ShowProductDto> GetById(int id)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            List<ShowProductDto> products = new List<ShowProductDto>();

            SqlCommand cmd = new SqlCommand("SelectById", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                ShowProductDto product = new ShowProductDto
                {
                    ProductId = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Description = reader.GetString(2),
                    Category = reader.GetString(3), // Category name
                    Price = reader.GetDecimal(4),
                    Stock = reader.GetInt32(5),
                    ImageUrl = reader.GetString(6)
                };

                var data = new
                {
                    product.ProductId,
                    product.Name,
                    product.Description,
                    product.Category,
                    product.Price,
                    product.Stock,
                    ImageUrl = $"{Request.Scheme}://{Request.Host}/Upload/{product.ImageUrl}"
                };

                conn.Close();
                return Ok(data);
            }
            else
            {
                conn.Close();
                return NotFound(new { message = id + " not found" });
            }
        }



        [HttpDelete]
        [Route("DeleteById/{id}")]
        public ActionResult DeleteById(int id)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            string query = "Select ImageUrl from Product where ProductId = @id";

            SqlCommand cmd1 = new SqlCommand(query, conn);
            cmd1.Parameters.AddWithValue("@id", id);
            conn.Open();
            string image = Convert.ToString(cmd1.ExecuteScalar());
            
            var imagePath = Path.Combine(Directory.GetCurrentDirectory(), "Upload", image);

            if (System.IO.File.Exists(imagePath))
            {
                System.IO.File.Delete(imagePath);
            }
            string query1 = "delete from Product Where ProductId = @id";
            SqlCommand command1 = new SqlCommand(query1, conn);

            command1.Parameters.AddWithValue("@id", id);

            command1.ExecuteNonQuery();
            conn.Close();
            return Ok(new { message ="Delete data Product" });
        }




    }
}
