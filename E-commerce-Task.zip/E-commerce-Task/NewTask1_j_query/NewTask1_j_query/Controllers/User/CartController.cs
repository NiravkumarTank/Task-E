﻿using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using NewTask1_j_query.Models.Admin;
using NewTask1_j_query.Models.Dtos;
using NewTask1_j_query.Models.User;

namespace NewTask1_j_query.Controllers.User
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly string ConnetionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Task_E-Commerce;Integrated Security=True;Trust Server Certificate=True";

        [HttpPost]
        [Route("AddToCart")]
        public ActionResult<CartDto> AddToCart([FromForm] CartDto cartDto)
        {

            try
            {
                SqlConnection conn = new SqlConnection(ConnetionString);

               
                string stockQuery = "SELECT Stock FROM Product WHERE ProductId = @pid";
                SqlCommand stockCmd = new SqlCommand(stockQuery, conn);
                stockCmd.Parameters.AddWithValue("@pid", cartDto.ProductId);

                conn.Open();
                int stock = (int)stockCmd.ExecuteScalar();
                conn.Close();

                if (stock == 0)
                {
                    return Ok(new { message = "No stock available for this product." });
                }

                string query = "SELECT COUNT(*) FROM Cart WHERE UserId = @uid AND ProductId = @pid";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@uid", cartDto.UserId);
                cmd.Parameters.AddWithValue("@pid", cartDto.ProductId);

                conn.Open();
                int countUser = (int)cmd.ExecuteScalar();
                conn.Close();

                if (countUser == 0)
                {
                    SqlCommand cmd1 = new SqlCommand("insertCartProductStock", conn);
                    cmd1.CommandType = CommandType.StoredProcedure;
                    cmd1.Parameters.AddWithValue("@uid", cartDto.UserId);
                    cmd1.Parameters.AddWithValue("@pid", cartDto.ProductId);

                    conn.Open();
                    cmd1.ExecuteNonQuery();
                    conn.Close();
                }
                else
                {

                    string updateStockQuery = "updtaeCartProductStock";
                    SqlCommand cmd2 = new SqlCommand(updateStockQuery, conn);
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Parameters.AddWithValue("@UserId", cartDto.UserId);
                    cmd2.Parameters.AddWithValue("@ProductId", cartDto.ProductId);

                    conn.Open();
                    int rowAffected = cmd2.ExecuteNonQuery();
                    conn.Close();

                    if (rowAffected > 0)
                    {
                        return Ok(new { message = "Stock Increase successfully.", data = cartDto });
                    }
                    else
                    {
                        return Ok(new { message = "No product available, stock is 0." });

                    }
                }

                return Ok(cartDto);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
            }




        [HttpGet("{userId}")]
        public ActionResult<IEnumerable<ShowCartDto>> GetAllCart([FromRoute] int userId)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);


            SqlCommand cmd = new SqlCommand("ShowAllCart", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", userId);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            List<ShowCartDto> cartDtos = new List<ShowCartDto>();

            while (reader.Read())
            {
                ShowCartDto showCartDto = new ShowCartDto
                {   ProductId = reader.GetInt32(reader.GetOrdinal("ProductId")),
                    ImageUrl = $"{Request.Scheme}://{Request.Host}/Upload/{reader.GetString(reader.GetOrdinal("ImageUrl"))}",
                    Name = reader.GetString(reader.GetOrdinal("Name")),
                    Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                    Stock = reader.GetInt32(reader.GetOrdinal("Stock"))
                };

                cartDtos.Add(showCartDto);
            }

            conn.Close();

            if (cartDtos.Any())
            {
                return Ok(cartDtos);
            }
            else
            {
                return BadRequest("No carts found for the specified user.");
            }
        }




        [HttpPost]
        [Route("DecreaseStock")]
        public ActionResult DecreaseStock([FromForm] CartDto cartDto)
        {
            try
            {
                SqlConnection conn = new SqlConnection(ConnetionString);

                SqlCommand cmd = new SqlCommand("decreaseStock", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@uid", cartDto.UserId); 
                cmd.Parameters.AddWithValue("@pid", cartDto.ProductId);
                conn.Open();
                int result = cmd.ExecuteNonQuery();
                conn.Close();

                if (result > 0)
                {
                    return Ok(new { message = "Stock decreased successfully." });
                }
                else
                {
                    return BadRequest("Failed to decrease the stock.");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("DeleteCart")]
        public ActionResult DeleteCart(int uid, int pid)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            conn.Open ();
            //string query = "DELETE FROM Cart WHERE UserId = @UserId AND ProductId = @ProductId";

            SqlCommand cmd = new SqlCommand("removeToCart", conn);
            cmd.CommandType= CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id",pid);
            cmd.Parameters.AddWithValue("@uid", uid);
            int row = cmd.ExecuteNonQuery();
            conn.Close();
            if (row > 0)
            {
                return Ok(new { message = "Product removed from cart successfully." });
            }
            else 
            {
                return NotFound();
            }

        }



    }
}
