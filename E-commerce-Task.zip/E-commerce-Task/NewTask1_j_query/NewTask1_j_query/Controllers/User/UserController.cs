﻿using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using NewTask1_j_query.Models.Dtos;
using NewTask1_j_query.Models.User;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace NewTask1_j_query.Controllers.User
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly string ConnetionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Task_E-Commerce;Integrated Security=True;Trust Server Certificate=True";

        

        [HttpPost]
        [Route("Registration")]
        public ActionResult<UserModel> CreatUser([FromForm] UserModel user)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            
                string emailCheck = "SELECT COUNT(1) FROM UserModel WHERE Email = @email";
                SqlCommand checkEmailCmd = new SqlCommand(emailCheck, conn);
                checkEmailCmd.Parameters.AddWithValue("@email", user.Email);

                conn.Open();
                int emailExists = (int)checkEmailCmd.ExecuteScalar();
                conn.Close();

                if (emailExists > 0)
                {
                    return Ok(new { message = "Email already exists" });
                }

                SqlCommand cmd = new SqlCommand("Insert_UserModel", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@fname", user.FirstName);
                cmd.Parameters.AddWithValue("@lname", user.LastName);
                cmd.Parameters.AddWithValue("@email", user.Email);
                cmd.Parameters.AddWithValue("@password", user.Password);
                cmd.Parameters.AddWithValue("@phonenumber", user.PhoneNumber);
                cmd.Parameters.AddWithValue("@gender", user.Gender);


            conn.Open();
                int row = cmd.ExecuteNonQuery();
                conn.Close();

                if (row > 0)
                {
                    return Ok(new { data = user, message = "Registration successful" });
                }
                else
                {
                    return BadRequest(new { message = "Error, no data inserted" });
                }
            
        }



        [HttpGet]
        [Route("GetAllUser")]
        public ActionResult<List<UserModel>> GetUsers()
        {
            List<UserModel> users = new List<UserModel>();
            SqlConnection conn = new SqlConnection(ConnetionString);
            //string query = "select * from UserModel";
            SqlCommand cmd = new SqlCommand("SelectAllUserModel", conn);
            cmd.CommandType= CommandType.StoredProcedure;

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                UserModel user = new UserModel()
                {
                    UserId = reader.GetInt32(0),
                    FirstName = reader.GetString(1),
                    LastName = reader.GetString(2),
                    Email = reader.GetString(3),
                    PhoneNumber = reader.GetString(5),
                    Gender = reader.GetString(6),
                };
                users.Add(user);    
            }
            var data = users.Select(p => new {
                p.UserId,
                p.FirstName,
                p.LastName,
                p.Email,
                p.PhoneNumber,
                p.Gender
            });
            conn.Close();
            return Ok(data);
        }



        [HttpGet]
        [Route("GetByIdUser/{id}")]
        public ActionResult<List<UserModel>> GetById(int id)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            SqlCommand cmd = new SqlCommand("SelectByIdUserModel", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@UserId", id);


            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                UserModel user = new UserModel()
                {
                    UserId = reader.GetInt32(0),
                    FirstName = reader.GetString(1),
                    LastName = reader.GetString(2),
                    Email = reader.GetString(3),
                    PhoneNumber = reader.GetString(5),
                    Gender = reader.GetString(6),
                };

                var data = new
                {
                    user.UserId,
                    user.FirstName,
                    user.LastName,
                    user.Email,
                    user.PhoneNumber,
                    user.Gender
                };
                conn.Close();
                return Ok(data);
            }
            return BadRequest(new { message = "no data  " });
        }


        [HttpDelete]
        [Route("DeleteById/{id}")]
        public ActionResult<List<UserModel>> DeleteById(int id)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            //string query = "Delete from UserModel Where UserId = @id";
            SqlCommand cmd = new SqlCommand("DeleteUserModel", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@id", id);

            conn.Open();
            int row =cmd.ExecuteNonQuery();
            conn.Close();

            if (row > 0)
            {
                   return Ok(new { message = id + " is Deleted" });
            }
            return NotFound(new { message = id + " is not Found" });
        }


        [HttpPut]
        [Route("UpdateUser/{id}")]
        public ActionResult<UserModel> UpdateData(int id, [FromBody] UpdateUserDto userDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SqlConnection conn = new SqlConnection(ConnetionString);

            SqlCommand cmd = new SqlCommand("UpdateUserModel", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@fname", userDto.FirstName);
            cmd.Parameters.AddWithValue("@lname", userDto.LastName);
            cmd.Parameters.AddWithValue("@email", userDto.Email);
            cmd.Parameters.AddWithValue("@phone", userDto.PhoneNumber);
            cmd.Parameters.AddWithValue("@gender", userDto.Gender ?? string.Empty);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            return Ok(new { message = "Data updated successfully", data = userDto });
        }




        [HttpPost]
        [Route("Login")]
        public ActionResult<Login> LoginData([FromForm] Login login)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);

            SqlCommand cmd = new SqlCommand("CheckUserLogin", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@email", login.Email);
            cmd.Parameters.AddWithValue("@pws", login.Password);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                int userId = Convert.ToInt32(reader["UserId"]);
                string firstName = Convert.ToString(reader["FirstName"]);
                string role = Convert.ToString(reader["Role"]);

                conn.Close();

                if (role == "Admin")
                {
                    return Ok(new
                    {
                        message = "Login successful",
                        data = new
                        {
                            UserId = userId,
                            FirstName = firstName,
                            Role = "Admin"
                        }
                    });
                }
                else 
                {
                    return Ok(new
                    {
                        message = "Login successful",
                        data = new
                        {
                            UserId = userId,
                            FirstName = firstName,
                            Role = "User"
                        }
                    });
                }

            }
            else
            {
                conn.Close();
                return Ok(new { message = "Invalid Email or password" });
            }
        }
    }
}
