﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using NewTask1_j_query.Models.Admin;

namespace NewTask1_j_query.Controllers.User
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly string ConnetionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Task_E_Commerce;Integrated Security=True;Trust Server Certificate=True";

        [HttpPost]
        [Route("CategoryAdd")]
        public ActionResult<Category> AddCategory([FromForm]Category category)
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            string query = "INSERT INTO Category (c_Name) VALUES (@name)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@name", category.c_Name);
            conn.Open();
            int row = cmd.ExecuteNonQuery();
            conn.Close();

            if (row > 0)
            {
                return Ok(new { message = "Category Inserted.", data = category });
            }
            else
            {
                return BadRequest();
            }
        }




        [HttpGet]
        [Route("CategoryShow")]
        public ActionResult<List<Category>> ShowAllCategory()
        {
            SqlConnection conn = new SqlConnection(ConnetionString);
            string query = "Select* from Category ";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            cmd.ExecuteNonQuery();

            List<Category> categories = new List<Category>();
           
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Category category = new Category()
                {
                    c_Id = reader.GetInt32(0),
                    c_Name = reader.GetString(1)
                };
                categories.Add(category);
            }
            conn.Close();

           return Ok(categories);
        }

    }
}
