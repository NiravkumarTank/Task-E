﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Data;

namespace NewTask1_j_query.Controllers.User
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly string ConnetionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Task_E_Commerce;Integrated Security=True;Trust Server Certificate=True";

        // POST: api/Order
        [HttpPost]
        public IActionResult PlaceOrder([FromForm] int userId)
        {
            if (userId <= 0)
            {
                return BadRequest("Invalid user ID.");
            }

            string checkCartQuery = "SELECT COUNT(*) FROM Cart WHERE UserId = @UserId";
            string insertOrderQuery = @"
                INSERT INTO OrderTable (UserId, Status)
                VALUES (@UserId, 'true');
                SELECT SCOPE_IDENTITY();"; // Get the newly inserted OrderId

            string insertOrderItemsQuery = @"
                INSERT INTO OrderItems (OrderId, ProductId, Quantity, UserId)
                SELECT @OrderId, ProductId, Stock, UserId
                FROM Cart
                WHERE UserId = @UserId"; // Insert the cart items into OrderItems

            string deleteCartItemsQuery = "DELETE FROM Cart WHERE UserId = @UserId";

            using (SqlConnection conn = new SqlConnection(ConnetionString))
            {
                try
                {
                    conn.Open();

                    // Check if the user has items in their cart
                    using (SqlCommand checkCartCmd = new SqlCommand(checkCartQuery, conn))
                    {
                        checkCartCmd.Parameters.AddWithValue("@UserId", userId);
                        int cartItemCount = (int)checkCartCmd.ExecuteScalar();

                        if (cartItemCount > 0)
                        {
                            // There are items in the cart, so insert the order and change status to 'true'
                            using (SqlCommand insertOrderCmd = new SqlCommand(insertOrderQuery, conn))
                            {
                                insertOrderCmd.Parameters.AddWithValue("@UserId", userId);
                                int orderId = Convert.ToInt32(insertOrderCmd.ExecuteScalar());

                                // Insert cart items into OrderItems table
                                using (SqlCommand insertOrderItemsCmd = new SqlCommand(insertOrderItemsQuery, conn))
                                {
                                    insertOrderItemsCmd.Parameters.AddWithValue("@OrderId", orderId);
                                    insertOrderItemsCmd.Parameters.AddWithValue("@UserId", userId);
                                    insertOrderItemsCmd.ExecuteNonQuery();
                                }

                                // Once the order is placed, remove cart items
                                using (SqlCommand deleteCartCmd = new SqlCommand(deleteCartItemsQuery, conn))
                                {
                                    deleteCartCmd.Parameters.AddWithValue("@UserId", userId);
                                    deleteCartCmd.ExecuteNonQuery();
                                }

                                // Return the order ID of the newly created order
                                return Ok(new { message = "Order placed successfully", OrderId = orderId });
                            }
                        }
                        else
                        {
                            // No items in cart, show message
                            return BadRequest("You have no items in your cart. Please add items to your cart first.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Log the error or handle it as needed
                    return StatusCode(StatusCodes.Status500InternalServerError, $"Internal server error: {ex.Message}");
                }
            }
        }
    }
}
