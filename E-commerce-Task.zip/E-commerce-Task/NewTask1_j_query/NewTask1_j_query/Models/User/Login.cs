﻿namespace NewTask1_j_query.Models.User
{
    public class Login
    {
        public string Email { get; set; }
        public string Password { get; set; }
        //public string? Role { get; set; } = "User";
    }
}
